# Sobha MDI · Agents service · Project context

> Auto-loaded by Claude Code on session start in this repo. Update this
> file when shipping anything that changes architecture, conventions,
> or the parked-items list. Don't grow past ~450 lines — keep tight.

> **Last major refresh: 2026-04-26** — Phase 6 (External Subject /
> Sobha Anchor doctrine + KPI lens + Tier-1 location intelligence) +
> Phase 7 (Friday contextual launcher: chips, TTS proxy, RAG memory,
> market lead in brief). Sobha portfolio synced from MIS xlsx —
> 49 projects across 11 communities anchor every LLM stage.

## ⚡ Quick reference (read this before grepping)

**Live URL:** `https://sobha-mdi-agents-production.up.railway.app` · Railway project `peaceful-contentment` / service `sobha-mdi-agents`.

**LLM stack — three roles, three models:**
- `LLM_MODEL` (`openai/gpt-oss-120b`) → direct flows: classifier-fast, CEO scan, pattern prose, investigation `chat_json` calls. Reasoning model — `tools/nvidia_llm.py:_call` falls back to `reasoning_content` when `content` is empty.
- `LLM_CREW_MODEL` (`llama-3.3-70b-versatile`) → CrewAI flows ONLY: `crews/daily_brief_crew.py`, `crews/deep_dive_crew.py`. Reasoning models break litellm's content extractor.
- `LLM_CLASSIFIER_MODEL` (`openai/gpt-oss-20b`) → per-raw-item classification.
- `NVIDIA_API_KEY` → embeddings ONLY (`nv-embedqa-e5-v5`, 1024 dim). Don't swap — re-embedding cost is high.

**Six LLM stages, all anchored to Sobha context (`tools/sobha_context.py`):**
1. Classifier → `tools/nvidia_llm.py:classify_intel` (appends portfolio summary to `INTEL_SYSTEM`)
2. Daily brief crew → `crews/daily_brief_crew.py` (Researcher + Writer agents in `_build_crew`)
3. CEO scan → `flows/ceo_scan_flow.py:CEO_SCAN_SYSTEM` (region-aware, regional context per call)
4. Pattern prose → `tools/pattern_detection.py:PROSE_SYSTEM` (per-pattern competitive overlap)
5. Investigation implications → `flows/investigation_flow.py:466` passes `get_competitive_overlap(developer_slug)` to `crews/investigation_crew.py:write_implications`
6. Deep-dive crew → `crews/deep_dive_crew.py` (Writer backstory has `format_overlap_for_llm(dev_slug)`)

**Doctrine: External Subject / Sobha Anchor.** External moves are the SUBJECT of every claim. Sobha is the LENS — exposure assessment, KPI benchmark, relevance filter. NEVER grammatical subject. KPI lens framework in `tools/sobha_context.py:KPI_LENS`. Data-gap shape: `"Need: <X>. Delegate to: <web_search | DLD lookup | Sobha analyst | nobody>."` Never fabricate.

**Sobha portfolio (the anchor):** `sobha_projects` table (migration 012). Sync via `python scripts/sync_sobha_mis.py --file <path>` OR `POST /admin/sync-sobha-mis` (multipart). 49 projects, 38,810 units across Hartland I/II/Extension, SZR, Motor City, Sobha Reserve, Al Yufrah, Al Ain Road, Dubai Harbour, JLT. Adjacency map: `_COMMUNITY_ADJACENCY` (Tier-1 location intelligence — Tier-2 geocoding deferred).

**50 scouts** (`agents/scouts/*`, all wired in `flows/ingest_flow.py`):
gnews · reddit · youtube · forum · instagram · bayut · dubizzle · linkedin · gdelt · sec_edgar · ir_pages (DFM/ADX) · industry_research · policy_wire (WAM/Zawya) · architecture · trade_press (incl. TechCrunch/HousingWire) · trakheesi · dld_projects (direct API) · us_permits (Austin Socrata) · au_building (ABS NSW+QLD) · houston_permits · github_leaks (gated on `GITHUB_TOKEN`) · emart_auctions · wayback_diff · page_hash · uae_press.

Tavily resilience: `tools/tavily_search.py` has 4h TTL cache + `Semaphore(8)` + 429 backoff + optional Brave fallback (`BRAVE_API_KEY`).

**Friday surfaces** (text-chat sibling of LiveKit voice agent — voice lives in separate repo `~/projects/sobha-mdi-friday-voice`):
- `GET /api/friday-suggestions` — 5 chips, robustness-gated (brief / event / pattern / cluster / market). Each carries `context_id` for fact-pack injection.
- `POST /api/friday-chat` — SSE streaming. Accepts `context_id`, `session_id`. Injects portfolio summary + market snapshot + RAG memory (top-4 from `friday_conversations`) + chip-resolved fact pack.
- `POST /api/friday-tts` — Deepgram audio/mpeg proxy. Frontend feeds sentences from chat stream.
- `POST /api/friday-rate` — thumbs up/down per turn (training corpus for future fine-tune).
- All turns persisted to `friday_conversations` table (migration 013) with NIM embedding for RAG. RPC: `match_friday_memory(query_embedding, match_count, similarity_threshold)`.

**Migrations applied to Supabase (in order):** 008 signal_region · 009 ceo_scans · 010 market_patterns · 011 page_snapshots · 012 sobha_projects · 013 friday_conversations.
**⚠️ Always use additive ALTER + dedupe variants** (not `create table if not exists` alone) — older versions of these tables exist from prior sessions and the constraints fail otherwise.

**Required env vars (Railway):** `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`, `LLM_CREW_MODEL`, `LLM_CLASSIFIER_MODEL`, `NVIDIA_API_KEY`, `TAVILY_API_KEY`, `APIFY_TOKEN`, `DEEPGRAM_API_KEY` (for `/api/friday-tts`). Optional: `LANGFUSE_*`, `BRAVE_API_KEY`, `GITHUB_TOKEN`, `AZURE_*` (Sobha MIS Azure SP — currently `invalid_resource`, IT-admin grant pending).

**Key endpoints:**
- Triggers: `POST /run/ingest`, `POST /run/daily-brief`, `POST /run/ceo-scan`, `POST /run/pipeline`, `POST /investigate/{signal_id}`, `POST /deep-dive/{dev_slug}`
- Inspectors: `GET /status`, `GET /admin/sobha-portfolio`, `GET /admin/sobha-overlap?dev=<slug>`, `GET /admin/sobha-project?q=<query>`, `GET /patterns`, `GET /patterns/history`
- SSE: `GET /run/ceo-scan/stream`

**Common workflows:**
- Manual full refresh: `curl -X POST <url>/run/pipeline` (5-15 min — server keeps running past curl timeout)
- Brief-only refresh: `curl -X POST <url>/run/daily-brief` (~10s with crew model)
- Sync MIS after monthly update: `python scripts/sync_sobha_mis.py --file <path>` OR multipart upload to `/admin/sync-sobha-mis`

**Parked items** (don't re-discover):
- Direct Trakheesi HTML scrape — Tavily-mediated path works, direct needs interactive iteration on pagination
- Dubai Pulse direct API — needs free dev key signup
- USPTO TSDR — paywalled since Oct 2025
- NSW Planning per-DA API — B2G only, no private path
- ChangeTower — replaced with `page_hash_scout`
- Tier-2 location intelligence (geocoding via Nominatim) — queued
- Confidence scoring (Phase 5.2) — deferred until critic flag corpus
- Self-critique v2 (feed flags back to Writer) — currently flags-only-log
- Path B/C multilingual TTS (ElevenLabs / Sarvam AI) — deferred until MD wants Hindi audio replies

## What this is

Internal "Managing Director Intelligence" agent backend for **Sobha
Realty** (Dubai luxury developer with a footprint in Abu Dhabi, USA
[Texas + nationwide], Australia [Brisbane], plus emerging-market
opportunity scanning). Watches global real-estate signals, classifies
them, auto-investigates high-priority ones, and produces:

1. **Morning brief** (existing) — daily narrative + top-7 + per-category
   synthesis. Focused on Dubai competitor moves.
2. **CEO scan** (NEW, 2026-04-25) — per-region strategic synthesis
   with dynamic sections (Tech / Partnership / Talent / M&A /
   Regulatory / Macro / Growth / Overall). Net-new only when the
   anti-replication filter ships.
3. **Deep dives** — on-demand 3-agent crew per developer.

Audience: MD Francis Alfred. CEO scan was framed for a higher altitude
("CEO" originally) but ships under the "MD Scan" surface — same person
wearing both hats.

Companion frontend repo: `/Users/manasmohan/projects/sobha-mdi`.
Both deploy continuously from `main`.

## Stack

- Python 3.11, FastAPI, APScheduler
- CrewAI 0.80.0 (used only for daily brief narrative + per-developer deep-dive)
- **Groq Cloud (primary chat)** — Llama 3.3 70B for synthesis,
  Llama 3.1 8B Instant for classification + small-format calls.
  Routes via OpenAI-compatible API; CrewAI uses litellm's native
  `groq/` adapter when `LLM_BASE_URL` contains `groq.com`.
- NVIDIA NIM (embeddings only) — `nv-embedqa-e5-v5` (1024-dim) for
  pgvector dedup. Falls back to title-hash if NIM unset.
- Supabase (Postgres + pgvector)
- Tavily — agent-grade web search for the investigation spider
  + LinkedIn scout. Free-source-first elsewhere.
- Apify — Instagram, Bayut, Dubizzle scraping (Dubai-only) +
  on-demand YouTube search.
- Langfuse v3 — observability (tracing on `daily_brief_flow`,
  `ingest_flow`, `investigation_flow`, `deep_dive_crew`,
  `ceo_scan_flow`)
- Hosted on Railway: `sobha-mdi-agents-production.up.railway.app`

## Pipeline (end to end)

The pipeline runs as a **chained sequence twice daily** at 05:00 and
13:00 GST. Processing only fires on ingest success — the MD's rule
("don't process before signals are in") is now an enforced dependency,
not coincidental cron timing.

```
05:00 / 13:00 GST  ──→  ingest_flow.run()  ──→  daily_brief_flow.run()  ──→  ceo_scan_flow.run("daily")
                              ↓ (on success)         ↓ (on success — brief failure doesn't block scan)
                          auto-fires investigations on priority=high signals (semaphore-cap 2)
```

### 1. **9 scouts** (parallel, return_exceptions=True)

Region tagging at scout level: each scout stamps `region` +
`country_code` into `raw_json`; promotion path lifts these onto
the signals row. Classifier output also emits region for cases
where scouts didn't (global queries, undated content).

- `gnews_scout` — Google News, **18 region-tagged queries** across
  5 regions (Dubai 7 + AD 3 + USA 3 + AU 3 + global 2). Free RSS.
- `reddit_scout` — **9 subs** (r/dubai, r/dubairealestate, r/abudhabi,
  r/RealEstate, r/austin, r/Dallas, r/AusProperty, r/AusFinance,
  r/brisbane). Pre-filter regex extended with US/AU vocab. Free.
- `youtube_scout` — 16 curated channels via channel RSS, transcripts
  via youtube-transcript-api (Apify fallback when blocked). Free.
- `forum_scout` — Bayut blog + PF blog + ExpatForum RSS. Free.
- `linkedin_scout` — Tavily with `include_domains=['linkedin.com']`,
  **25 devs × 2 intent buckets** across Dubai/AD/USA/AU. Tavily
  is paid; this scout exists because LinkedIn has no public RSS.
  **URL-snowflake decode** parses post date from activity ID
  (`>>22` of the URL's 19-digit number = Unix ms timestamp); IG
  drops Tavily's null `published_date` for ~70% of LinkedIn results
  so the URL is the source of truth for date.
- `instagram_scout` — 24 dev + broker accounts via Apify (**Dubai-only**).
- `bayut_scout` — Apify epctex/bayut-scraper, 8 developer-filtered URLs (**Dubai-only**).
- `dubizzle_scout` — Apify epctex/dubizzle-scraper, 7 dev URLs (**Dubai-only**).
- `gdelt_scout` — **NEW (2026-04-25)**. GDELT 2.0 Doc API, free, no
  key. ~150K global news sources with `sourcecountry` baked in.
  7 query buckets covering US-Texas, US-REIT, AU-Brisbane,
  AU-developers, AE-AbuDhabi, global-luxury, global-tech. Single
  biggest unlock for non-Dubai coverage.

**Cost discipline rule**: don't expand Apify scrapers to non-Dubai
regions. Every other region is covered by free sources (gnews + reddit
+ gdelt + linkedin via Tavily + youtube channel RSS). Apify stays
Dubai-only.

### 2. `intel_raw`
Every scout's items upserted by `dedup_key` (sha256 of title + domain).
Idempotent re-runs.

### 3. Classifier
`agents/analysts/classifier.py` — single chat call per unprocessed raw row.
**Routes through `LLM_CLASSIFIER_MODEL` (Llama 3.1 8B Instant) when
set**, falls back to `LLM_MODEL`. Returns:
`{keep, priority, confidence, category, decision_tag, headline, dek,
entities, region, country_code, reason}`. Prompt v3 in
`tools/nvidia_llm.INTEL_SYSTEM` (region tagging rules pinned).

### 4. `intel_scored`
Every scored row, kept or not, joined back to `raw_id`. `region` and
`country_code` are stripped before insert (not columns on this table)
but kept in-memory through to promotion.

### 5. Promotion (`flows/ingest_flow._promote_to_signals`)
- Read `region` from `raw.raw_json` (scout-stamped) → fall back to
  classifier output → null
- Embed `headline + dek` via NIM nv-embedqa-e5-v5 (1024-dim)
- Age decay (`tools/freshness.decay_priority`, **tightened 2026-04-25**)
  — fresh ≤ 7d, stale ≥ 45d (was 14d / 180d). Stale = reject.
- Novelty score — rare developer = 1.0, common (>10 in 14d) = 0.25
- `tools/supabase_tool.upsert_signal` — pgvector cosine ≥0.86 over
  30d → merge. Else title-hash. Else fresh insert.
  **Defensive**: catches "region/country_code column missing" exceptions
  and retries without those fields, so ingest survives if migration 008
  hasn't applied yet.

### 6. Auto-investigation
For every newly promoted `priority=high` signal,
`_fire_investigation` queues `investigation_flow.run` semaphore-capped
at 2 concurrent. Hourly `investigation_sweep` catches misses
(lookback 72h, max 5/tick) and marks events `stale` after 7d untouched.

### 7. Investigation flow (`flows/investigation_flow.run`)

1. `entity_resolver` (chat_json, with retry + headline fallback)
2. `spider.gather` — Tavily general + news (with **score ≥ 0.3 filter**
   and **90-day age cap** — see "Conventions") + Apify YouTube search
   (transcript fetch on top 6) + internal signals lookup. Returns
   ~30-40 deduped evidence items.
3. `investigation_crew.extract_facts` (chat_json, with retry) — strict
   JSON of every concrete field with per-field confidence.
4. `investigation_crew.write_implications` (chat_json, with retry).
   **Output is `scenarios[]`** (opportunity / risk / watch with
   `claim`, `what_supports`, `what_would_confirm`, `what_would_reject`,
   `sobha_exposure`, `action`) — replaced the old single-track
   `angles[]`. Backward-compat `angles[]` is auto-derived from
   scenarios for the daily brief reader. **Gates on extract_facts
   sentinels** — empty facts + 'fact extraction failed' → skip
   implications, return `EMPTY_IMPL`. Status escalates to
   `conflicted`.
5. Persist to `market_events`, `event_evidence`, `event_facts`,
   `event_implications` (with `scenarios` JSONB column,
   migration 007), `event_runs`.
6. Upsert canonical `projects` row (slug match → Jaccard ≥0.5 fuzzy
   match for cross-spelling dedup). `market_events.project_id`
   back-links.
7. Set `market_events.status` to `ready` or `conflicted` (escalates
   when `extract_facts` returns the failure sentinel OR unresolved
   count grew vs prior run).

### 8. Daily brief (`flows/daily_brief_flow.run`)

Runs **inside the chained pipeline** (no standalone cron anymore).

- Fetch candidates: **adaptive 48h → max 72h `last_seen_at`** plus
  **2-day `source_published_at` cap** (tightened 2026-04-25 — was
  36h / 30d / 7d-fallback). Excludes signal_ids that appeared in
  briefs in the last 7 days (cross-brief dedup; today's own row is
  excluded from the lookup so manual regens still work).
- Pick top-7 by `priority × confidence × freshness` with
  **per-developer cap of 2** in pass 1 (diversity), fill remaining
  slots in pass 2 ignoring the cap.
- For each top signal, lift attached `event_implications` (incl.
  `scenarios`) AND `event_facts.facts` so the brief source cards
  can render PSF / units / mix / payment plan inline.
- **Sequenced (not parallel) calls**: 5 per-category synth → 4-agent
  CrewAI narrative → pointer generator. Stays under Groq free-tier
  12K TPM cap.
- Per-category synth + pointer-generator route through
  `role="fast"` → small model (LLM_CLASSIFIER_MODEL). Only the
  CrewAI narrative + investigation steps stay on the large model.
- Upsert into `daily_briefs` keyed by day.

### 9. CEO scan (`flows/ceo_scan_flow.run`) — NEW 2026-04-25

- One Supabase fetch (no per-region query — `.or_("region.is.null,...")`
  silently returns 0 rows when combined with other filters; client-side
  bucketing is robust)
- Bucket signals by region in Python: NULL/unknown → 'other'
- Sequenced LLM call per region (5 regions): produces dynamic-sections
  output `{stamp, sections: [{key, heading, claim, rows, action}, ...]}`
- Upsert into `ceo_scans` (migration 009) keyed by
  (region, cadence, scan_day) — manual regens overwrite
- Cadence: `daily` (1d lookback) or `weekly` (7d lookback)
- Cron: daily fires inside the 05:00 + 13:00 chained pipeline;
  weekly on Sunday 05:30 GST

## Endpoints (FastAPI)

- `GET  /health`, `GET /status`
- `POST /run/ingest` — scouts only
- `POST /run/daily-brief` — brief only
- `POST /run/ceo-scan?cadence=daily|weekly` — scan only
- `POST /run/pipeline` — **NEW**: full chain (ingest → brief → ceo_scan_daily)
- `POST /deep-dive/{slug}` — on-demand 3-agent crew per developer
- `POST /investigate/{signal_id}` — manual or re-investigation
- `GET  /signals/recent?limit=10`
- `POST /signals/{id}/feedback?verdict=useful|noise`
- `GET  /events?limit=N&offset=N&developer_slug=&event_type=`
- `GET  /events/{id}` — event + facts + implications + evidence
- `GET  /events/{id}/runs` — investigation history
- `GET  /projects?limit=N&developer_slug=&branded_only=`
- `GET  /projects/{id}` — project + rolled-up events
- `GET  /daily-brief?day=YYYY-MM-DD`
- `GET  /ceo-scan?region=X&cadence=daily|weekly&day=YYYY-MM-DD` — **NEW**
- `GET  /debug/azure-intel` — Azure SP token + endpoint probe

## File map

```
agents/
  analysts/classifier.py       chat_json scoring (routes through small model via role="classifier")
  scouts/                      9 scouts (Pipeline §1) — gdelt added 2026-04-25
  investigators/
    entity_resolver.py
    spider.py                  Tavily + YT + signals — score ≥ 0.3 + age ≤ 90d filters
crews/
  daily_brief_crew.py          4-agent narrative
  deep_dive_crew.py            3-agent per-dev memo
  investigation_crew.py        extract_facts + write_implications (scenarios shape)
flows/
  ingest_flow.py               scout → score → promote → fire-auto. Region+country_code plumbed.
  daily_brief_flow.py          adaptive window + diversity cap + cross-brief dedup
  ceo_scan_flow.py             NEW — per-region strategic synthesis
  investigation_flow.py        seed → event_* tables, scenarios persistence
  investigation_sweep.py       hourly catch-up + stale marker
tools/
  apify_client.py              generic Apify actor runner
  apify_youtube.py             on-demand YT search
  azure_intel.py               Azure AD SP client + diagnose probe
  crewai_llm.py                LLM adapter — Groq via litellm's groq/ prefix when llm_base_url contains groq.com
  evidence_typing.py           source → type taxonomy + reliability
  freshness.py                 publish-date parse + age decay (7d / 45d)
  nvidia_llm.py                chat_json + embed + INTEL_SYSTEM. Role-aware provider (classifier/fast/default).
                               429 auto-retry with Groq's "try again in Xs" hint.
  observability.py             Langfuse v3 init + @observe
  supabase_tool.py             upsert_signal + match_signal RPC. Defensive insert for region migration.
  tavily_search.py             Tavily wrapper
  yt_transcript.py             youtube-transcript-api + Apify fallback
db/
  schema.sql                   base tables
  migrations/
    002_pgvector_dedup.sql     vector(1024) + match_signal RPC
    003_brief_pointers.sql     daily_briefs.pointers JSONB
    004_intelligence_layer.sql market_events + 3 child tables
    005_signal_freshness.sql   signals.source_published_at
    006_intelligence_layer_v2  evidence_type + event_runs + projects
    007_scenarios.sql          event_implications.scenarios JSONB (replaced angles in render path)
    008_signal_region.sql      NEW — signals.region + signals.country_code
    009_ceo_scans.sql          NEW — ceo_scans table for CEO scan flow output
schedule.py                    APScheduler — chained pipeline 05:00 + 13:00 GST,
                               ceo_scan_weekly Sun 05:30, sweep hourly
server.py                      FastAPI lifespan + endpoints (incl. /run/pipeline + /ceo-scan)
settings.py                    pydantic-settings — llm_base_url + llm_classifier_model added
```

## Conventions / quirks (read before editing)

- **Chained pipeline rule**: processing only fires on ingest success.
  Brief failure doesn't block CEO scan; ingest failure short-circuits
  the chain. Don't add downstream cron jobs that bypass this.
- **Groq is primary**, NIM is embeddings-only. CrewAI talks to Groq via
  litellm's native `groq/` prefix (NOT `openai/<model>` with custom
  base_url — that 404s because litellm rewrites the URL path).
  `tools/crewai_llm.py` has the detection logic.
- **Role-aware model selection** (`tools/nvidia_llm._chat_provider`):
  - `role="default"` → `LLM_MODEL` (70B for synthesis)
  - `role="classifier"` or `role="fast"` → `LLM_CLASSIFIER_MODEL`
    (8B for per-signal scoring, brief category synth, brief pointer JSON)
  - Embeddings always NIM. Don't break this.
- **429 backoff is automatic** — `_call` parses Groq's "try again in Xs"
  hint and retries once with the suggested wait (capped 60s). Don't
  add manual retry loops in callers; the layer handles it.
- **CrewAI is reserved** for narrative writing only (daily brief +
  per-dev deep-dive). Investigation uses single-shot `chat_json`
  calls because each step has well-defined output and CrewAI's
  4-agent ceremony adds latency without quality.
- **URL leakage rule**: never feed source URLs to the LLM in prompts
  that produce prose. They leak into output. Server strips, dashboard
  scrubs again as belt-and-suspenders.
- **Region tagging precedence**: scout `raw_json.region` →
  classifier `region` → null (groups under 'other' on dashboard).
- **Source-published-date is the source of truth**, NOT `last_seen_at`
  or `first_seen_at`. The dashboard filter and brief candidate window
  both anchor on `source_published_at`. Re-indexed old content with
  fresh `last_seen_at` no longer leaks into the brief.
- **LinkedIn URL snowflake**: `_decode_url_timestamp` extracts post
  creation time from the activity/share/ugcPost ID (>>22 = Unix ms).
  Do NOT rely on Tavily's `published_date` for LinkedIn — null ~70%
  of the time.
- **CEO scan bucketing is client-side**, not PostgREST `.or_()`.
  Earlier `.or_("region.is.null,region.eq.other")` silently returned
  0 rows when combined with other filters. Fetch once, group in
  Python, scan per non-empty bucket.
- **Dedup precedence**: pgvector cosine ≥0.86 over 30d → title-hash
  sha256 → fresh insert.
- **Identity stability**: `_upsert_event` looks up by `seed_signal_id`
  FIRST so re-investigations update the same event row regardless of
  slug drift. Then slug-based dedup as fallback.
- **Project dedup**: Jaccard ≥0.5 on token sets after stopword
  removal. Catches `Mercedes-Benz Places by Binghatti` ≡
  `Mercedes-Benz Places - Binghatti City`.
- **All chat_json flows have retry**: bare call → retry with
  "start with {" nudge. Llama drops JSON mode under load otherwise.
- **Auto-investigation is semaphore-capped at 2 concurrent**.
  Earlier 9-parallel ingest run rate-limited NIM and produced
  degenerate events.
- **Brief is sequential, not parallel**: 5 category synth → narrative
  crew → pointers, all `await`-ed in series. Parallel `asyncio.gather`
  burst-tripped Groq's 12K TPM cap.
- **Brief dedup window**: skip signal_ids present in any brief from
  the last 7 days. Today's row is excluded from the lookup so manual
  regens of today's brief still have their own candidate pool.
- **Apify scope**: Dubai-only (IG, Bayut, Dubizzle). Don't extend
  Apify to other regions; cost scales fast and free sources cover.
- **Scenarios shape** in `event_implications`: `[{stance:
  opportunity|risk|watch, claim, what_supports, what_would_confirm,
  what_would_reject, sobha_exposure, action}, ...]`. Backward-compat
  `angles[]` is auto-derived from scenarios for legacy readers.
- **Langfuse v3 only** — Cloud project rejects v2 SDK silently.
  Auth via `get_client()` from env.
- **Scout failure isolation**: all scouts use
  `asyncio.gather(..., return_exceptions=True)` so one source dying
  never kills the run.
- **YT transcripts**: Railway IP is blocked by youtube-transcript-api
  for many videos. Apify (`pintostudio~youtube-transcript-scraper`)
  is the fallback.

## Required env (Railway)

**Required:**
- `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`
- `LLM_BASE_URL` (e.g. `https://api.groq.com/openai/v1`)
- `LLM_API_KEY` (Groq key)
- `LLM_MODEL` (e.g. `llama-3.3-70b-versatile`)
- `TAVILY_API_KEY`
- `APIFY_TOKEN`

**Highly recommended:**
- `LLM_CLASSIFIER_MODEL` (e.g. `llama-3.1-8b-instant`) — splits the
  per-signal classifier and brief small-format calls onto a cheaper
  model. Without this, free-tier Groq daily-token-cap exhausts during
  any heavy testing.
- `NVIDIA_API_KEY`, `NVIDIA_MODEL` — only used for embeddings now.
  Still needed unless you accept title-hash dedup.

**Optional:**
- `LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, `LANGFUSE_HOST`
- `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET`,
  `AZURE_API_BASE_URL`, `AZURE_API_SCOPE` — when wired, Sobha MIS
  data flows into investigation benchmarks.

## Currently parked

1. **Sobha initiatives ingestion + anti-replication filter** — user
   intends to provide an Excel/Word file with current Sobha initiatives.
   Once received: parse → `sobha_initiatives` table → consult during
   promotion + ceo_scan_flow → drop matching candidates BEFORE they
   reach the dashboard. Hard exclude, no UI strip — invisible filter.
   **Status as of 2026-04-25**: file not yet provided. CEO scan still
   surfaces everything; matched-with-Sobha items must be filtered by
   eye until file lands.
2. **Cross-signal pattern detection** (Phase 3) — e.g. "market shifting
   to compact living" from multi-launch unit-size deltas. Requires
   structured fact extraction maturity (sqft, payment-plan terms,
   absorption rate) that we don't have today. Not on critical path.
3. **Honest streaming progress UI** — frontend currently shows faux
   stages with real backend in parallel. Phase 3 swaps for SSE/WS
   from a real `/scan/{job_id}/progress` endpoint emitting per-region
   per-call events. Contract documented; backend instrumentation TBD.
4. **Sobha MIS / Azure API auth** — admin needs to grant the SP an
   API permission role on the `sr-mdo-app-sobhaintel-prod` app
   registration. Foundation in `tools/azure_intel.py`. Probe via
   `GET /debug/azure-intel`. The DevOps SP currently only has ARM
   scope. Same parked status as before.
5. **Groq Dev Tier upgrade ($5/mo)** — recommended but not committed.
   Free tier hits TPM (12K) and TPD (100K) caps under heavy testing.
   429 auto-retry handles per-minute waves but doesn't help when
   daily quota exhausts. User has been told 5+ times; it's their call.
6. **Secret rotation** — Apify, Tavily, Langfuse pub+sec, Azure
   client secret, Groq key have all been pasted in chat at some
   point. Rotate at the source, paste only into Railway env.

## What I deliberately DON'T build (judgment calls)

- **Self-hosted scraping farm** (Selenium/Playwright on a VPS) —
  evaluated 2026-04-25. Apify is justified for Dubai-only listings
  + IG. Other regions covered by free sources. Self-hosting would
  cost more (proxies + maintenance) than it saves.
- **Region expansion of Apify scrapers** — non-Dubai listings data
  isn't CEO-altitude data. Free sources cover everything strategic
  regions need.
- Durable job queue (Redis/SQS) — current `asyncio + sweep` handles
  current scale; revisit at >100 investigations/day.
- 6-dimension signal scoring exposed to classifier — adds prompt
  complexity; novelty alone covers 80%.
- Feature taxonomy / project fingerprinting — premature without
  50+ projects in `projects` to define empirically.
- Comparison surface UI (competitor vs Sobha side-by-side) —
  useless without MIS.

## Stylistic preferences (from accumulated user feedback)

- **Concise responses, no end-of-turn summaries.** User reads diffs.
- **No comments on what code does** — only WHY when non-obvious.
- **No premature abstractions** — three similar lines beat a helper.
- **Verify before claiming done.** UI changes need browser checks
  unless user explicitly opts out (they have, several times).
- **Commit on explicit request only.**
- **Skip browser preview verification** — standing directive in this
  project. User reviews changes themselves.
- **Don't paste keys / secrets in chat.** Always direct the user
  to paste into Railway env vars or the source console.

## Onboarding prompt for a fresh AI session

If you're new to this repo and the file above isn't enough:

> Read `CLAUDE.md` at the repo root for full context. The system is
> a multi-region real-estate intelligence backend that scouts public
> sources (Dubai/AD/USA/Australia/Other), classifies signals,
> auto-investigates high-priority ones, writes a daily brief, and
> produces a per-region CEO scan. Companion frontend lives at
> `/Users/manasmohan/projects/sobha-mdi`. Pipeline runs as a chained
> sequence at 05:00 + 13:00 GST — processing only fires on ingest
> success. Groq is primary chat (NIM is embeddings only); a smaller
> 8B model handles classifier + brief small-format calls via
> `role="fast"` in `chat_json`. Three open parked items: Sobha
> initiatives file (anti-replication), MIS Azure auth, Groq Dev Tier
> upgrade decision. Don't paste keys in chat — Railway env only.
> The user has overruled browser-preview verification — never run
> the verification workflow.
