# Sobha MDI · Forward Roadmap

> Last updated: 2026-04-25 evening, after Phase 3 (patterns + SSE) shipped.
> This is the working roadmap, not a marketing doc. When in doubt about
> what's next, read this top-to-bottom and pick the smallest thing in the
> highest-priority phase.

## Where we are

| Phase | Status | What it covered |
|---|---|---|
| 1 — UI scaffold | ✅ shipped | MD Scan page, region tabs, faux progress, mock content |
| 2 — Data layer | ✅ shipped (initiatives parser parked) | region tagging in classifier, `ceo_scan_flow`, `/api/ceo-scan`, schema for `sobha_initiatives` |
| 3 — Patterns + honesty | ✅ shipped | cross-signal pattern detection (4 detectors), honest SSE streaming, regulatory rail, Developer Intelligence Index, dynamic country split, UX polish |
| 4 — Quality polish | 🔵 next | country-chips clickable, pattern LLM-prose, drill-down modals, patterns persistence |
| 5 — Intelligence depth | 🟡 queued | better fact extraction, move-type taxonomy, historical pattern view, anti-replication filter |
| 6 — Internal data | 🟠 external blockers | Sobha MIS, comparison surface, DLD unblock |
| 7 — Distribution | ⚪️ later | push notifications, email digest, mobile real testing |
| 8 — Custom MDI assistant | ⚪️ exploratory | RAG over Supabase + Sobha-tuned persona; POC building tonight |

---

## Phase 4 — Quality polish (~6-8h, user-confirmed order)

Goal: tighten what shipped in Phase 3 from "works" to "feels finished."

### 4.1 Country chips clickable filter (~45m)
Today the country chips on the Other region are visual-only. Make them filter:
- Click "VN · 4" → CEO scan body re-renders with only Vietnam-country signals + a "× clear filter" pill
- Persists in localStorage so user can come back to the same view
- Patterns rail also filters

### 4.2 Pattern LLM-prose layer (~1.5h)
Today the 4 detectors emit hand-crafted claims. Wrap each match in a `chat_json` call (role="fast" → 8B model) that produces an explicit Sobha-implication paragraph. Cache to avoid duplicate LLM calls within a 24h window.

### 4.3 Drill-down modals (~3-4h)
Replace `go('m2')` / `go('m3')` route navigation with overlay drawer pattern. Click a tag in MD Scan → modal opens with deeper context, back closes modal not page. Same drawer infra as the existing investigation drawer.

### 4.4 Patterns persistence (~1h)
New table `market_patterns` keyed by (key, week_iso). Persist detected patterns weekly. Enables historical pattern view in Phase 5.3.

### 4.5 `/api/market-data` 503 fix (~30m)
Diagnose Vercel function. Likely missing FRED key, or upstream Frankfurter/CoinGecko outage. Verify + repair.

---

## Phase 5 — Intelligence depth (~10-12h)

Goal: make the LLM outputs richer by giving them more structured input.

### 5.1 Better fact extraction (~6-8h)
Today `event_facts.facts` extracts categorical fields. Missing the numeric depth that pattern detection actually needs:
- `unit_size_sqft` per unit type
- `absorption_velocity_units_per_week` (when scout finds it)
- `payment_plan_post_handover_pct` parsed from "60/40 post-handover"
- `broker_commission_bps`
- `developer_capex_aed_mn` (for capital-tagged signals)

Requires:
- Prompt extension in `crews/investigation_crew.FACTS_SYSTEM`
- Schema addition in `event_facts` (already JSONB, no migration needed — just key naming convention)
- Frontend drawer fact-strip extended to render these

### 5.2 Move-type taxonomy widening (~1h)
Classifier today emits a thin set: `launch / partnership / handover / other`. Codex's earlier 10-bucket taxonomy:
- Project Launch · Project Update · Pricing/Payment · Partnership/Brand · Land/Pipeline · Capital/Financing · Sales Channel · Leadership/Hiring · Regulatory · Rumor/Early Signal

Prompt + enum widening only. UI tag styling stays compatible (we already render `event_type` as a coloured tag).

### 5.3 Historical pattern view (~3h)
Once 4.4 (patterns persistence) lands, build a `/patterns/history` route showing patterns over time:
- "Capital cluster appeared 3 weeks running"
- "Meydan micro-market activity peaked week of 2026-04-18"
- Frontend: a small chart per pattern key (sparkline of evidence counts)

### 5.4 Anti-replication filter (~30m)
Triggers when initiatives file lands. Parse → `sobha_initiatives` table → embed-compare candidates against Sobha's existing work in promotion path → drop matches before they reach the dashboard. Hard exclude, no UI tag.

---

## Phase 6 — Internal data wiring (external blockers)

| Item | Blocker | Time when unblocked |
|---|---|---|
| Sobha MIS via Azure SP | Admin grant on `sr-mdo-app-sobhaintel-prod` | ~4-6h |
| Comparison surface | Above | ~3h |
| DLD live data | Azure SWA UAE-North migration (or VPS relay) | ~1-2 days |
| Anti-replication filter live | Initiatives file from user | ~30m |
| Groq Dev Tier | $5/mo decision | 5m to upgrade, 0 code |

---

## Phase 7 — Distribution & polish (~8h)

### 7.1 Push notifications (PWA) (~3h)
iOS 16.4+ supports web push. Service worker groundwork already exists in `service-worker.js`. Need:
- VAPID keys
- Subscribe UI (after first page load, polite prompt)
- Backend endpoint to send push when high-priority signal lands or daily brief regenerates

### 7.2 Email digest fallback (~2h)
For mornings when the MD doesn't open the dashboard. Send the daily brief as HTML email at 04:30 GST. Mailgun/Resend integration.

### 7.3 Mobile real testing (~2h)
The CSS sweep was deductive. Test on actual iPad + iPhone, fix layout breaks. Drawer behaviour on iPhone Safari. PWA install flow.

### 7.4 Source feed expansion (~1h + subscription cost)
- NewsAPI as paid backup ($449/mo)
- Specific RE-trade publications via RSS
- ABS / FRED / DLD official feeds when we can hit them

---

## Phase 8 — Custom MDI assistant (exploratory, POC tonight)

Goal: a Cursor-equivalent for Sobha real-estate intelligence. Ask plain-language questions, get CEO-altitude answers grounded in our data.

### 8.1 RAG-powered Q&A (POC tonight, ~1h)
- Embed user question → pgvector match against signals + events
- Pull top-K relevant rows
- Send to Groq with a heavily Sobha-flavoured system prompt
- Return a CEO-style answer with citations

POC delivered as `scripts/ask_mdi.py` — runs locally with the user's Groq + Supabase env vars.

### 8.2 Web chat UI (~2h)
Add an "Ask MDI" search bar to MD Scan. Same backend.

### 8.3 Domain-tuned model (proper) (~2-3 weeks)
Real fine-tune options if RAG isn't enough:
- Llama 3.1 8B fine-tune on Sobha's historical decisions + briefs (Together AI, Replicate, or self-hosted)
- Cost: ~$50-200 for training, ongoing inference comparable to Groq
- ROI: only if the RAG approach hits clear quality ceilings

### 8.4 Tool-augmented agent (~1 week)
The LLM gets actual tools — query Supabase, run pattern detection on demand, look up specific developers. More agentic. Best after RAG proves the persona works.

---

## Decision principles (when in doubt)

1. **Curation > volume.** The MDI is a CEO-altitude scanner. More feeds, more sections, more layers all hurt. Less, sharper, more actionable wins.
2. **Free sources before paid.** Apify is justified Dubai-only. Outside Dubai: gnews + reddit + GDELT + Tavily cover. Don't expand Apify.
3. **Determinism before LLM where possible.** Pattern detection is hand-coded for a reason. LLM-prose layer is icing, not foundation.
4. **Status > scaffold.** Empty/error states must be honest about what's happening. No fake progress, no fake content.
5. **Standing user directives** (do not violate without re-asking):
   - Skip browser preview verification — user reviews themselves
   - Don't paste keys/secrets in chat
   - Concise responses, no end-of-turn summaries

---

## When user returns

Likely starting point: Phase 4.1 (country chips clickable) — smallest, was at the top of their list. Then 4.2 (LLM-prose) → 4.4 (patterns persistence) → 4.3 (drill-down modals) since modals is the heaviest single piece of UI work in Phase 4.
