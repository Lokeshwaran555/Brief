# Sobha MDI · Agents

Python scout + classifier service feeding the [sobha-mdi](https://github.com/Jatin0129/sobha-mdi) dashboard via Supabase.

Week-1 scope: Google News early-signal scout → NVIDIA NIM classifier → Supabase (`intel_raw` · `intel_scored` · `signals`). Scouts for Bayut / PFinder / Reddit / IG / LinkedIn / YouTube / Telegram come later; see `../sobha-mdi/docs/SYSTEM_RESEARCH.md` for the full plan.

## Architecture

```
  gnews_scout ─┐
               │
               ▼           APScheduler (every 15 min)
         ingest_flow ────▶ Supabase (intel_raw → intel_scored → signals)
               ▲                         ▲
               │                         │
         classifier                 sobha-mdi Vercel app reads
         (NVIDIA Llama 3.3)         /api/intel from here (later)
```

Single FastAPI process on Fly.io. Same process hosts the scheduler and a `/run/ingest` HTTP trigger for manual kicks.

## Local run

```bash
cp .env.example .env            # fill in values or use the committed .env
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Apply the schema once via Supabase SQL Editor:
#   https://supabase.com/dashboard/project/radgoeohjtwjwsrtkcgw/sql/new
# Paste db/schema.sql and run.

uvicorn server:app --reload --port 8080
# then: curl -XPOST http://localhost:8080/run/ingest
```

## Deploy to Fly.io

Prereq: `brew install flyctl`, `fly auth login` (Google OAuth works).

```bash
fly launch --no-deploy --copy-config      # uses this fly.toml
fly secrets set \
  SUPABASE_URL="$SUPABASE_URL" \
  SUPABASE_SERVICE_ROLE_KEY="$SUPABASE_SERVICE_ROLE_KEY" \
  NVIDIA_API_KEY="$NVIDIA_API_KEY" \
  NVIDIA_MODEL="meta/llama-3.3-70b-instruct"
fly deploy
fly logs
```

Verify:

```bash
curl https://sobha-mdi-agents.fly.dev/health
curl https://sobha-mdi-agents.fly.dev/status
curl -XPOST https://sobha-mdi-agents.fly.dev/run/ingest
```

Then check the Supabase table editor — `intel_raw` should have rows within ~15 seconds, `intel_scored` a minute later.

## Layout

| Path | Role |
|---|---|
| `agents/scouts/gnews_scout.py` | Ports the 7 leak-vocabulary Google News queries from the dashboard's `/api/intel` |
| `agents/analysts/classifier.py` | Bounded-concurrency scorer; wraps `tools.nvidia_llm.classify_intel` |
| `flows/ingest_flow.py` | scout → upsert raw → score → insert scored → promote to `signals` |
| `tools/supabase_tool.py` | Upsert helpers. `signals` clustered by title-hash (pgvector upgrade later) |
| `tools/nvidia_llm.py` | Llama-3.3 chat + defensive JSON parsing. `INTEL_SYSTEM` prompt matches dashboard |
| `schedule.py` | APScheduler, fires `ingest_flow.run` every `INGEST_INTERVAL_MINUTES` |
| `server.py` | FastAPI; starts scheduler in lifespan, exposes `/health`, `/status`, `/run/ingest` |
| `db/schema.sql` | One-time Supabase schema — paste into SQL Editor |

## Env vars

| Var | Required | Notes |
|---|---|---|
| `SUPABASE_URL` | yes | Project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | yes | Service role — bypasses RLS |
| `NVIDIA_API_KEY` | yes | From build.nvidia.com |
| `NVIDIA_MODEL` | no | Default `meta/llama-3.3-70b-instruct` |
| `INGEST_INTERVAL_MINUTES` | no | Default 15 |
| `INTEL_QUERY_LIMIT` | no | Default 40 |
| `INTEL_CONCURRENCY` | no | Default 4 |
| `PORT` | no | Default 8080 |
| `LOG_LEVEL` | no | Default INFO |

## Not yet wired

- Bayut / PFinder / Reddit / IG / LinkedIn / YouTube / Telegram scouts (weeks 2–3)
- `dedup.py` (pgvector semantic clustering — week 2)
- `pulse_flow.py` (nightly per-dev z-scores — week 3)
- `brief_flow.py` (daily 04:00 GST — week 3)
- `weekly_brief_crew.py` (Sunday 22:00 — week 4)
- Dashboard switch-over from `/api/intel` RSS-fetch to Supabase read (week 2)
